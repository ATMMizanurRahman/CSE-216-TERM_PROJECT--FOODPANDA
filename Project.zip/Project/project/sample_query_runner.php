<?php
	include 'show_table.php';
	
	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  
	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);
	
	if(isset($_POST['sample_query_taker']) && !empty($_POST['sample_query_taker'])){
		
		$sql = $_POST['sample_query_taker'];
		
		$result = pg_query($dbconn, $sql);
	
		if (!$result) {
			echo "<strong>Query error.......<strong></br>";
			exit;
		}
		else{
			
			show_table_data($result);
			
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
			pg_free_result($result);
			
		}
	}
	else{
		die("Enter a valid Query");
	}

?>