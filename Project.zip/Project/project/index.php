

<?php 

	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  

	//echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);
		
?>



<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<title>FOODPANDA HOMEPAGE</title>
		<style>
		/* Main */
			#menu{
				width: 100%;
				margin: 0;
				padding: 10px 0 0 0;
				list-style: none;  
				background: #323;
				border-radius: 20px;
			}
			#menu li{
				float: left;
				padding: 0 0 20px 0;
				position: relative;
			}
			#menu a{
				float: left;
				height: 15px;
				padding: 20px 50px;
				color: #ffffff;
				font: bold 15px/25px Arial, Helvetica;
				text-decoration: none;
				text-shadow: 0 1px 0 #000; 
			}
			#menu li:hover > a{ color: #CC3333; }
			#menu ul{
				list-style: none;
				margin: 0;
				padding: 0;    
				display: none;
				position: absolute;
				top: 35px;
				left: 0;
				background: #222;
				border-radius: 5px;
			}
		    
				
			#menu:after{
				visibility: hidden;
				display: block;
				font-size: 0;
				content: "";
				clear: both;
				height: 0; 
			}
			
			
			body{
				color : white;
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			div {
				
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}

			fieldset {
				position:relative;
				margin-top:50px;
				background: linear-gradient( #272829 , #414345);
				padding-top:20px;
			}
			
			legend {
				position:absolute;
				top:-15px;
				background:linear-gradient(#0f2027, #203a43, #2c5364);

				color:white;
				border:2px solid #00000; 
				padding:1px 10px;
			}
			input[type=submit]{
				color: #000099;
				font-weight: bold;
			}
			input[type=text] {
			    width: 7%;
			    padding: 3px 15px;
				color: #003300;
				font-weight: bold;
			    margin: 8px ;
			    box-sizing: border-box;	
			}
			textarea{
				background: url(http://i.imgur.com/2cOaJ.png);
				background-attachment: local;
				background-repeat: no-repeat;
				padding-left: 35px;
				font-weight: bold;
				color: #ffffff;
				padding-top: 10px;
				border: 3px solid #fff2c8;	
				box-shadow: 2px 3px 5px #7f747f;
			}
			h4{
				color : white;
			}

		</style>

	</head>
	
	<body>
		<ul id="menu">
			<li><a href="erd.php">Entity Relationship Diagram</a></li>
			<li><a href="smpl.php">Simple Queries</a></li>
			<li><a href="cmplx.php">Complex Queries</a></li>    
			<li><a href="func.php">Functions and Triggers</a></li>
			<li><a href="quer.php">A Very Simple Query Editor</a></li>

		</ul>
		
		
		<div align="center">
			<br><br><br>
			<img src="image.jpg" alt="FOODPANDA" width="200" height="80">
			<h1>Welcome to FoodPanda</h1>
			<br><br><br>
		</div>
		
		<h3 ></br></br>&nbsp;&nbsp;&nbsp;&nbsp;Developped By: Ahsanul Ameen Sabit
			& Mizanur Rahman Shuvo</br></br>
			&nbsp;&nbsp;&nbsp;&nbsp;Student ID: 1605047 & 1605060</br></br>
		</h3>
		
			<br><br><br>
		<form method='post' action='tables.php'>
			<fieldset >
				<legend> <strong> Tables and Views <strong></legend>
				<h4>Press any button to see all data from a particular table: 	</h4>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="customers" value="CUSTOMERS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="riders" value="RIDERS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="regions" value="REGIONS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="countries" value="COUNTRIES" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="locations" value="LOCATIIONS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="adress" value="ADRESS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="restaurants" value="RESTAURANTS" onclick="enter()" >
				<input style="margin:5px;" type='submit' formtarget="_blank" name="item_menus" value="ITEM_MENUS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="orders" value="ORDERS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="order_line" value="ORDER_LINE" onclick="enter()" >  
				<input style="margin:5px;" type='submit' formtarget="_blank" name="payments" value="PAYMENTS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="promo_codes" value="PROMO_CODES" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="customer_details" value="CUSTOMER_DETAILS(view)" onclick="enter()" ></br>
			</fieldset>
		</form><br><br><br><br>
		
		
		
		
		
	</body>
</html>

