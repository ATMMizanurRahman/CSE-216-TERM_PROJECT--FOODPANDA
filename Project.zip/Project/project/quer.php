
<!DOCTYPE html>
<html>

	<head>
	
		<title>Query Editor</title>

	
		<style>
	
			body{
				color : white;
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			div {
				
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}

			fieldset {
				position:relative;
				margin-top:50px;
				background: linear-gradient( #272829 , #414345);
				padding-top:20px;
			}
			
			legend {
				position:absolute;
				top:-15px;
				background:linear-gradient(#0f2027, #203a43, #2c5364);

				color:white;
				border:2px solid #00000; 
				padding:1px 10px;
			}
			input[type=submit]{
				color: #000099;
				font-weight: bold;
			}
			input[type=text] {
			    width: 7%;
			    padding: 3px 15px;
				color: #003300;
				font-weight: bold;
			    margin: 8px ;
			    box-sizing: border-box;	
			}
			textarea{
				background: url(http://i.imgur.com/2cOaJ.png);
				background-attachment: local;
				background-repeat: no-repeat;
				padding-left: 35px;
				font-weight: bold;
				color: #ffffff;
				padding-top: 10px;
				border: 3px solid #fff2c8;	
				box-shadow: 2px 3px 5px #7f747f;
			}
			h4{
				color : white;
			}
			
		
		</style>
	</head>
	
	
	<body > 
		
		
		<!--------------------------------------------------------SQL---form 06----------------------------------------------------------------------->
		<div align="center">
			<br><br><br>
			<br><br><br>
			<br><br><br>
			<h1>...WRITE Beautiful Queries HERE...</h1>
		</div>
		<br><br><br>
		<form id = "boxoffice" method='post' action='sample_query_runner.php'>
			<fieldset>
				<legend> <strong> Query Editor <strong></legend>
				<h4>Execute a postgres query here</h4>
				
				<textarea placeholder="Write Beautiful Queries......" wrap="hard" rows="17" cols="100" formtarget="_blank" name="sample_query_taker" ></textarea></br>
				<input style="margin:5px;" type='submit' formtarget="_blank" name="sample_query_runner" value="EXECUTE" onclick="enter()" ></br>
				
			</fieldset>
			
		</form><br><br><br><br>
		
				
		<!--------------------------------------------------------TABLES---form 01----------------------------------------------------------------------->
		<br><br><br>
		<form method='post' action='tables.php'>
			<fieldset >
				<legend> <strong> Table and Views <strong></legend>
				<h4>Press any button to see all data from a particular table: 	</h4>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="customers" value="CUSTOMERS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="riders" value="RIDERS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="regions" value="REGIONS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="countries" value="COUNTRIES" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="locations" value="LOCATIIONS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="adress" value="ADRESS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="restaurants" value="RESTAURANTS" onclick="enter()" >
				<input style="margin:5px;" type='submit' formtarget="_blank" name="item_menus" value="ITEM_MENUS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="orders" value="ORDERS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="order_line" value="ORDER_LINE" onclick="enter()" >  
				<input style="margin:5px;" type='submit' formtarget="_blank" name="payments" value="PAYMENTS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="promo_codes" value="PROMO_CODES" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="customer_details" value="CUSTOMER_DETAILS(view)" onclick="enter()" ></br>
			</fieldset>
		</form><br><br><br><br>
		
		
		<!--------------------------------------------------------Functions---form 02----------------------------------------------------------------------->

		
		
		
	</body>
</html>












