<?php
	include 'execute_complex.php';
	
	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  
	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);

	
	if(isset($_POST["compq_1_input"])){
		compq_1($dbconn, $result);
	}
	else if(isset($_POST["compq_2_input"])){
		compq_2($dbconn, $result);
	}
	else if(isset($_POST["compq_3_input"])){
		compq_3($dbconn, $result);
	}
	else if(isset($_POST["compq_4_input"])){
		compq_4($dbconn, $result);
	}
	else if(isset($_POST["compq_5_input"])){
		compq_5($dbconn, $result);
	}else if(isset($_POST["compq_6_input"])){
		compq_6($dbconn, $result);
	}else if(isset($_POST["compq_7_input"])){
		compq_7($dbconn, $result);
	}
	else{
		echo 'Somethin Wrong....!!!!';
	}
?>



