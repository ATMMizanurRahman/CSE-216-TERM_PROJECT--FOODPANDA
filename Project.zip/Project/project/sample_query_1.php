<?php
	include 'show_table.php';
	
	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  
	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);
	
	
	
	$sql = file_get_contents("query.txt");
	
	if (!$sql)  
	{ 
	   die ("File could not be opened"); 
	} 
	else{
		echo $sql.'<br>';
	}
	
	
	
	
	$result = pg_query($dbconn, $sql);
	
	if (!$result) {
		echo "<strong>Query error.......<strong></br>";
		exit;
	}
	else{
		
		show_table_data($result);
		
		$notice = pg_last_notice($dbconn, 2);
		foreach ($notice as $key => $value) {
			echo "$value<br>";
		}
		pg_free_result($result);
		
	}
	
	
	

?>