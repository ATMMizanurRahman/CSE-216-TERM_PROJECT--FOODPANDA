<?php

	include 'table_view.php';

	
	//FUNCTION 01
	function simpq_1($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp1.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
	function simpq_2($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp2.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 2<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function simpq_3($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp3.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 3<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function simpq_4($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp4.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 4<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function simpq_5($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp5.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 5<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
	function simpq_6($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp6.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 6<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function simpq_7($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp7.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 7<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function simpq_8($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp8.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 8<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function simpq_9($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("simp9.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing simple query 9<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
?>




