<?php
	include 'execute_simple.php';
	
	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  
	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);

	
	if(isset($_POST["simpq_1_input"])){
		simpq_1($dbconn, $result);
	}
	else if(isset($_POST["simpq_2_input"])){
		simpq_2($dbconn, $result);
	}
	else if(isset($_POST["simpq_3_input"])){
		simpq_3($dbconn, $result);
	}
	else if(isset($_POST["simpq_4_input"])){
		simpq_4($dbconn, $result);
	}else if(isset($_POST["simpq_5_input"])){
		simpq_5($dbconn, $result);
	}else if(isset($_POST["simpq_6_input"])){
		simpq_6($dbconn, $result);
	}else if(isset($_POST["simpq_7_input"])){
		simpq_7($dbconn, $result);
	}else if(isset($_POST["simpq_8_input"])){
		simpq_8($dbconn, $result);
	}
	else if(isset($_POST["simpq_9_input"])){
		simpq_9($dbconn, $result);
	}
	else{
		echo 'Somethin Wrong....!!!!';
	}
?>



