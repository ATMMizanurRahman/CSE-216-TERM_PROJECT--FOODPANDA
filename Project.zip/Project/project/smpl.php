

<!DOCTYPE html>
<html>

	<head>
	
		<title>Simpe Queries</title>
		
	
		<style>
	
			body{
				color : white;
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			div {
				
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}

			fieldset {
				position:relative;
				margin-top:50px;
				background: linear-gradient( #272829 , #414345);
				padding-top:20px;
			}
			
			legend {
				position:absolute;
				top:-15px;
				background:linear-gradient(#0f2027, #203a43, #2c5364);

				color:white;
				border:2px solid #00000; 
				padding:1px 10px;
			}
			input[type=submit]{
				color: #000099;
				font-weight: bold;
			}
			input[type=text] {
			    width: 7%;
			    padding: 3px 15px;
				color: #003300;
				font-weight: bold;
			    margin: 8px ;
			    box-sizing: border-box;	
			}
			textarea{
				background: url(http://i.imgur.com/2cOaJ.png);
				background-attachment: local;
				background-repeat: no-repeat;
				padding-left: 35px;
				font-weight: bold;
				color: #ffffff;
				padding-top: 10px;
				border: 3px solid #fff2c8;	
				box-shadow: 2px 3px 5px #7f747f;
			}
			h4{
				color : white;
			}
			
		
		</style>
	</head>
	
	
	<body > 
		
		<!--------------------------------------------------------SIMPLE---form 04----------------------------------------------------------------------->

		<div align="center">
			<br><br><br>
			<h1>All Simple Queries</h1>
			<br><br><br>
		</div>
		<br><br><br>
		<form method='post' action='simple.php'>
			<fieldset>
				<legend> <strong> All Simple Queries <strong></legend>
				<h3>Select and execute a Query :</h3><br>

			
				<fieldset>
					<legend><strong>RESTAURANTS & ATTRIBUTES of FOOD:</strong></legend> </br>
					<textarea disabled rows="6" cols="70" name="" id="simpq_1_description">
					<?php
						$fn = "simp1.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_1_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				
				<fieldset>
					<legend><strong>RESTAURANTS & CUSINESS of FOOD:</strong></legend> </br>
					<textarea disabled rows="6" cols="80" name="" id="simpq_2_description">
					<?php
						$fn = "simp2.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_2_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				
				<fieldset>
					<legend><strong>RESTAURANTS PROVIDES FREE DELIVERY:</strong></legend> </br>
					<textarea disabled rows="6" cols="80" name="" id="simpq_3_description">
					<?php
						$fn = "simp3.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_3_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>RESTAURANTS PROVIDES ONLINE PAYMENTS:</strong></legend> </br>
					<textarea disabled rows="6" cols="75" name="" id="simpq_4_description">
					<?php
						$fn = "simp4.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_4_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>RESTAURANTS PROVIDES SPECIAL OFFERS:</strong></legend> </br>
					<textarea disabled rows="5" cols="60" name="" id="simpq_5_description">
					<?php
						$fn = "simp5.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_5_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW MY VOUCHERS: </strong></legend> </br>
					<textarea disabled rows="5" cols="60" name="" id="simpq_6_description">
					<?php
						$fn = "simp6.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_6_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW ORDER STATUS: </strong></legend> </br>
					<textarea disabled rows="5" cols="60" name="" id="simpq_7_description">
					<?php
						$fn = "simp7.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_7_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW ALL ORDERS: </strong></legend> </br>
					<textarea disabled rows="4" cols="60" name="" id="simpq_8_description">
					<?php
						$fn = "simp8.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_8_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW PROMO CODE VALIDITY</strong></legend> </br>
					<textarea disabled rows="4" cols="60" name="" id="simpq_9_description">
					<?php
						$fn = "simp9.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="simpq_9_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
			</fieldset>
		</form>
		<br><br><br>
		<br><br><br>
		<br><br><br>
		
		
		
	</body>
</html>












