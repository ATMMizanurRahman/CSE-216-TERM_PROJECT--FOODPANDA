<?php

	//show_regions($dbconn, $result);
	//show_countries($dbconn, $result);
	//show_locations($dbconn, $result);
	//show_riders($dbconn, $result);
	//show_restaurants($dbconn, $result);
	//show_customers($dbconn, $result);
	//show_adress($dbconn, $result);
	//show_item_menus($dbconn, $result);
	//show_orders($dbconn, $result);
	//show_order_line($dbconn, $result);
	//show_payments($dbconn, $result);
	//show_promo_codes($dbconn, $result);


?>








<?php

	include 'show_table.php';

	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  

	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);
			
		
		
		
			
	$sql = 'SELECT * FROM "CUSTOMER_DETAILS"';
			
	///$sql = file_get_contents("query.txt");
	
	if (!$sql)  
	{ 
	   die ("File could not be opened"); 
	} 
	else{
		echo $sql.'<br>';
	}
	

	
	$result = pg_query($dbconn, $sql);
	
	if (!$result) {
		echo "<strong>Query error.......<strong></br>";
		exit;
	}
	else{
		
		show_table_data($result);
		$notice = pg_last_notice($dbconn);
		echo $notice.'</br>';		
		pg_free_result($result);
		
	}

		
	
	
?>






