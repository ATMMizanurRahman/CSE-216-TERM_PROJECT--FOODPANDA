

<!DOCTYPE html>
<html>

	<head>
		<title>Complex Queries</title>
		
	
		<style>
	
			body{
				color : white;
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			div {
				
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}

			fieldset {
				position:relative;
				margin-top:50px;
				background: linear-gradient( #272829 , #414345);
				padding-top:20px;
			}
			
			legend {
				position:absolute;
				top:-15px;
				background:linear-gradient(#0f2027, #203a43, #2c5364);

				color:white;
				border:2px solid #00000; 
				padding:1px 10px;
			}
			input[type=submit]{
				color: #000099;
				font-weight: bold;
			}
			input[type=text] {
			    width: 7%;
			    padding: 3px 15px;
				color: #003300;
				font-weight: bold;
			    margin: 8px ;
			    box-sizing: border-box;	
			}
			textarea{
				background: url(http://i.imgur.com/2cOaJ.png);
				background-attachment: local;
				background-repeat: no-repeat;
				padding-left: 35px;
				font-weight: bold;
				color: #ffffff;
				padding-top: 10px;
				border: 3px solid #fff2c8;	
				box-shadow: 2px 3px 5px #7f747f;
			}
			h4{
				color : white;
			}
			
		
		</style>
	</head>
	
	
	<body > 
		
		
		
		<div align="center">
			<br><br><br>
			<h1>All Complex Queries</h1>
			<br><br><br>
		</div>
		
		<!--------------------------------------------------------COMP---form 03----------------------------------------------------------------------->
	
	
		<br><br><br>
		<form method='post' action='complex.php'>
			<fieldset>
				<legend> <strong> All Complex Queries <strong></legend>
				<h3>Select and execute a Query :</h3><br>

				<fieldset>
					<legend><strong>FIND NEAREST FREE RIDER</strong></legend> </br>
					<textarea disabled rows="10" cols="70" name="" id="compq_1_description">
					<?php
						$fn = "comp1.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_1_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW NEAREST RESTAURANTS</strong></legend> </br>
					<textarea disabled rows="10" cols="70" name="" id="compq_2_description">
					<?php
						$fn = "comp2.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_2_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW ALL ITEMS</strong></legend> </br>
					<textarea disabled rows="10" cols="70" name="" id="compq_2_description">
					<?php
						$fn = "comp3.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_3_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW MY ADRESS</strong></legend> </br>
					<textarea disabled rows="14" cols="75" name="" id="compq_2_description">
					<?php
						$fn = "comp4.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_4_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW RESTAURANTS TOTAL INCOME</strong></legend> </br>
					<textarea disabled rows="14" cols="75" name="" id="compq_2_description">
					<?php
						$fn = "comp5.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_5_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW RIDERS TOTAL INCOME</strong></legend> </br>
					<textarea disabled rows="10" cols="70" name="" id="compq_2_description">
					<?php
						$fn = "comp6.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_6_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>SHOW_MOST_SOLD_ITEMS</strong></legend> </br>
					<textarea disabled rows="15" cols="80" name="" id="compq_2_description">
					<?php
						$fn = "comp7.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="compq_7_input" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
			</fieldset>
		</form>
		<br><br><br>
	
	
		<br><br><br><br>
		
		
		<br><br><br><br>
	
		
		
	</body>
</html>












