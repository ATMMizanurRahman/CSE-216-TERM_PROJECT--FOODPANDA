<?php 
	
	function show_table_data($result){
		
		if (!$result) {
			echo "<strong>Query error.......<strong></br>";
			exit;
		}
		
		$cmd_touples = pg_affected_rows($result);
		$cmd_fields = pg_num_fields($result);
				
		//echo $cmd_touples." rows are affected.</br>";
		//echo $cmd_fields." fields are shown.</br>";
		
		$i = 0;
		echo '</br><html><body><div align="center"><table border="2" ><tr>';
		while ($i < pg_num_fields($result)){
			$fieldName = pg_field_name($result, $i);
			echo '<td><strong>' . $fieldName . '</strong></td>';
			$i++;
		}
		echo '</tr>';
	
	
		$i = 0;
		while ($row = pg_fetch_row($result)) 
		{
			echo '<tr>';
			$count = count($row);
			$y = 0;
			while ($y < $count){
				$c_row = current($row);
				echo '<td>' . $c_row . '</td>';
				next($row);
				$y = $y + 1;
			}
			echo '</tr>';
			$i = $i + 1;
		}
		echo '</table></div></body></html></br></br>';
	}
	
	
	
?>