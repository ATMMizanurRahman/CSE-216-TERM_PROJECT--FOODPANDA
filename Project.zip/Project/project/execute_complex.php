<?php

	include 'table_view.php';

	
	//FUNCTION 01
	function compq_1($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp1.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
	function compq_2($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp2.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function compq_3($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp3.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function compq_4($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp4.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function compq_5($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp5.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
	function compq_6($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp6.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	function compq_7($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		//$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, file_get_contents("comp7.txt"));			
		if (!$result) {
			echo "<strong>Query error while executing complex query 1<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
?>




