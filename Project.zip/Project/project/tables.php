<?php
	include 'show_table.php';
	
	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  
	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);
	
	
	
	if(isset($_POST['customers']) && !empty($_POST['customers'])){
		show_customers($dbconn, $result);
	}
	else if(isset($_POST['riders']) && !empty($_POST['riders'])){
		show_riders($dbconn, $result);
	}
	else if(isset($_POST['regions']) && !empty($_POST['regions'])){
		show_regions($dbconn, $result);
	}
	else if(isset($_POST['countries']) && !empty($_POST['countries'])){
		show_countries($dbconn, $result);
	}
	else if(isset($_POST['locations']) && !empty($_POST['locations'])){
		show_locations($dbconn, $result);
	}
	else if(isset($_POST['adress']) && !empty($_POST['adress'])){
		show_adress($dbconn, $result);
	}
	else if(isset($_POST['restaurants']) && !empty($_POST['restaurants'])){
		show_restaurants($dbconn, $result);
	}
	else if(isset($_POST['item_menus']) && !empty($_POST['item_menus'])){
		show_item_menus($dbconn, $result);
	}
	else if(isset($_POST['orders']) && !empty($_POST['orders'])){
		show_orders($dbconn, $result);
	}
	else if(isset($_POST['order_line']) && !empty($_POST['order_line'])){
		show_order_line($dbconn, $result);
	}
	else if(isset($_POST['payments']) && !empty($_POST['payments'])){
		show_payments($dbconn, $result);
	}
	else if(isset($_POST['promo_codes']) && !empty($_POST['promo_codes'])){
		show_promo_codes($dbconn, $result);
	}
	else if(isset($_POST['customer_details']) && !empty($_POST['customer_details'])){
		show_customer_details($dbconn, $result);
	}
	else{
		echo '<strong>Problem Occurred</strong></br>';
	}

?>