

<!DOCTYPE html>
<html>

	<head>
	
		<title>Functions & TRIGGER</title>

		<style>
	
			body{
				color : white;
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			div {
				
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}

			fieldset {
				position:relative;
				margin-top:50px;
				background: linear-gradient( #272829 , #414345);
				padding-top:20px;
			}
			
			legend {
				position:absolute;
				top:-15px;
				background:linear-gradient(#0f2027, #203a43, #2c5364);

				color:white;
				border:2px solid #00000; 
				padding:1px 10px;
			}
			input[type=submit]{
				color: #000099;
				font-weight: bold;
			}
			input[type=text] {
			    width: 7%;
			    padding: 3px 15px;
				color: #003300;
				font-weight: bold;
			    margin: 8px ;
			    box-sizing: border-box;	
			}
			textarea{
				background: url(http://i.imgur.com/2cOaJ.png);
				background-attachment: local;
				background-repeat: no-repeat;
				padding-left: 35px;
				font-weight: bold;
				color: #ffffff;
				padding-top: 10px;
				border: 3px solid #fff2c8;	
				box-shadow: 2px 3px 5px #7f747f;
			}
			h4{
				color : white;
			}
			
		
		</style>
	</head>
	
	
	<body > 
		
		
		
		<!-----------------Functions---form 02----------------------------------------------------------------------->

	
		<div align="center">
			<br><br><br>
			<br><br><br>
			<br><br><br>
			<h1>All Functions and Triggers</h1>
		</div>
		
		
		<br><br><br>
		<form method='post' action='functions.php'>
			<fieldset>
				<legend> <strong> All Functions <strong></legend>
				<h3>Select and execute a function :</h3><br>

				<fieldset>	
					<legend><strong>........Order A FOOD!!!........</strong></legend> </br><br><br>
					<fieldset>
						<legend><strong>Create New Order:</strong></legend> </br>
						<textarea disabled rows="20" cols="90" name="" id="create_new_order_description">
						<?php
							$fn = "func1.txt";
							print htmlspecialchars(implode("",file($fn)));
						?>
						</textarea> </br>
						
						<br>Enter Customer_ID: &nbsp;<input type="text" name="create_new_order_input"><br/>
						<br><input style="margin:5px;" type='submit' formtarget="_blank" name="create_new_order_execute" value="Execute" onclick="enter()" > </br>
					</fieldset><br><br><br><br>
					
					<fieldset>
				<legend> <strong> All Triggers <strong></legend>
				<h3>CREATE AN ORDER TO SEE THE USE OF TRIGGERS: </h3><br>

			
				<fieldset>
					<legend><strong>TRIGGER 01: FILL_UP_ORDER_LINE</strong></legend> </br>
					<textarea disabled rows="20" cols="80" name="" id="trigger_1_description">
					<?php
						$fn = "trigger1.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
				</fieldset><br><br>
				
				
				<fieldset>
					<legend><strong>TRIGGER 02: FILL_UP_PAYMENTS</strong></legend> </br>
					<textarea disabled rows="30" cols="100" name="" id="trigger_2_description">
					<?php
						$fn = "trigger2.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
				</fieldset><br><br>
		
				
			</fieldset>	
					
					<fieldset>
						<legend><strong>Discard Order:</strong></legend> </br>

						<textarea disabled rows="15" cols="90" name="" id="discard_order_description">
						<?php
							$fn = "func2.txt";
							print htmlspecialchars(implode("",file($fn)));
						?>
						</textarea> </br>
						<br>Enter Order_ID: &nbsp;<input type="text" name="discard_order_input"><br/>
						<br><input style="margin:5px;" type='submit' formtarget="_blank" name="discard_order_execute" value="Execute" onclick="enter()" > </br>
					</fieldset><br><br>
				</fieldset>
				
				<fieldset>
					<legend><strong>Update Rider Status:</strong></legend> </br>
					<textarea disabled rows="15" cols="80" name="" id="update_rider_status_description">
					<?php
						$fn = "func3.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br>Enter Rider_ID: &nbsp;<input type="text" name="update_rider_status_input"><br/>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="update_rider_status_execute" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>Give User Rating:</strong></legend> </br>
					<textarea disabled rows="15" cols="80" name="" id="give_ratings_description">
					<?php
						$fn = "func4.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>					
					</textarea> </br>
					<br>Enter Customer_ID: &nbsp;<input style="margin:5px;" type="text" name="give_ratings_input1"><br/>
					<br>Enter Restaurant_ID: &nbsp;<input type="text" name="give_ratings_input2"><br/>
					<br>Enter Rating: &nbsp;<input style="margin:5px;" type="text" name="give_ratings_input3"><br/>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="give_ratings_execute" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
				<fieldset>
					<legend><strong>Update Order Price:</strong></legend> </br>
					<textarea disabled rows="15" cols="80" name="" id="update_order_price_description">
					<?php
						$fn = "func5.txt";
						print htmlspecialchars(implode("",file($fn)));
					?>
					</textarea> </br>
					<br>Enter Order_ID: &nbsp;<input type="text" name="update_order_price_input"><br/>
					<br><input style="margin:5px;" type='submit' formtarget="_blank" name="update_order_price_execute" value="Execute" onclick="enter()" > </br>
				</fieldset><br><br>
				
			</fieldset>
		</form>
		<br><br><br>
		
		<br><br><br>
		<form method='post' action='tables.php'>
			<fieldset >
				<legend> <strong> Table and Views <strong></legend>
				<h4>Press any button to see all data from a particular table: 	</h4>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="customers" value="CUSTOMERS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="riders" value="RIDERS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="regions" value="REGIONS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="countries" value="COUNTRIES" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="locations" value="LOCATIIONS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="adress" value="ADRESS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="restaurants" value="RESTAURANTS" onclick="enter()" >
				<input style="margin:5px;" type='submit' formtarget="_blank" name="item_menus" value="ITEM_MENUS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="orders" value="ORDERS" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="order_line" value="ORDER_LINE" onclick="enter()" >  
				<input style="margin:5px;" type='submit' formtarget="_blank" name="payments" value="PAYMENTS" onclick="enter()" > 
				<input style="margin:5px;" type='submit' formtarget="_blank" name="promo_codes" value="PROMO_CODES" onclick="enter()" ></br>
				
				<input style="margin:5px;" type='submit' formtarget="_blank" name="customer_details" value="CUSTOMER_DETAILS(view)" onclick="enter()" ></br>
			</fieldset>
		</form><br><br><br><br>
		
		
	</body>
</html>












