<?php

	include 'table_view.php';

	
	//FUNCTION 01
	function create_new_order($dbconn, $result, $customer_id){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT "CREATE_NEW_ORDER"('.$customer_id.')';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while executing CREATE_NEW_ORDER<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	// function 02
	function discard_order($dbconn, $result, $order_id){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT "DISCARD_ORDER"('.$order_id.')';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while executing DISCARD_ORDER<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	// function 03
	function give_ratings($dbconn, $result, $customer_id, $restaurant_id, $koto){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT "GIVE_RATINGS"('.$customer_id.', '.$restaurant_id.', '.$koto.')';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while executing GIVE_RATINGS<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	

	//function 04
	function refresh_foodpanda_path($dbconn, $result){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT "REFRESH_FOODPANDA_PATH"()';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while executing REFRESH_FOODPANDA_PATH<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	//function 05
	function update_order_price($dbconn, $result, $order_id){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT "UPDATE_ORDER_PRICE"('.$order_id.')';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while executing UPDATE_ORDER_PRICE<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}
	
	
	function update_rider_status($dbconn, $result, $rider_id){
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT "UPDATE_RIDER_STATUS"('.$rider_id.')';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while executing UPDATE_RIDER_STATUS<strong></br>";
			exit;
		}else{
			show_table_data($result);
			$notice = pg_last_notice($dbconn, 2);
			foreach ($notice as $key => $value) {
				echo "$value<br>";
			}
		}
		pg_free_result($result);
	}

?>




