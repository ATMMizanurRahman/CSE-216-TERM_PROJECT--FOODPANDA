
<!DOCTYPE html>
<html>

	<head>
		<title>ERD</title>

		<style>
	
			body{
				color : white;
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}
			div {
				
				background: #403A3E;  /* fallback for old browsers */
				background: -webkit-linear-gradient(to left, #BE5869, #403A3E);  /* Chrome 10-25, Safari 5.1-6 */
				background: linear-gradient(to left, #BE5869, #403A3E); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

			}

			fieldset {
				position:relative;
				margin-top:50px;
				background: linear-gradient( #272829 , #414345);
				padding-top:20px;
			}
			
			legend {
				position:absolute;
				top:-15px;
				background:linear-gradient(#0f2027, #203a43, #2c5364);

				color:white;
				border:2px solid #00000; 
				padding:1px 10px;
			}

			h4{
				color : white;
			}
			
		
		</style>
	</head>
	
	
	<body > 
				
		<fieldset>
			<!div align="center">
				<h1 align="center">Entity Relationship Diagram</h1>
				<img src="erd.jpg" alt="ERD" width=100% height=100%>
			<!/div>
		</fieldset>
		
		
	</body>
</html>






