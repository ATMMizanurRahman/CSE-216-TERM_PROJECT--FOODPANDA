<?php

	include 'table_view.php';

	function show_customers($dbconn, $result){
		
		echo '<div align="center">
			<strong>CUSTOMERS</strong>
		</div>';

		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "CUSTOMERS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing CUSTOMERS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	function show_riders($dbconn, $result){
		
		echo '<div align="center">
			<strong>RIDERS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "RIDERS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing RIDERS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	function show_regions($dbconn, $result){
			
		echo '<div align="center">
			<strong>REGIONS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "REGIONS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing REGIONS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	function show_countries($dbconn, $result){
			
		echo '<div align="center">
			<strong>COUNTRIES</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "COUNTRIES"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing COUNTRIES<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_locations($dbconn, $result){
			
		echo '<div align="center">
			<strong>LOCATIONS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "LOCATIONS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing LOCATIONS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	

	function show_adress($dbconn, $result){
			
		echo '<div align="center">
			<strong>ADRESS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "ADRESS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing ADRESS<strong></br>";
			exit;
		}else{

			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	function show_restaurants($dbconn, $result){
			
		echo '<div align="center">
			<strong>RESTAURANTS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "RESTAURANTS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing RESTAURANTS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_item_menus($dbconn, $result){
			
		echo '<div align="center">
			<strong>ITEM_MENUS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "ITEM_MENUS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing ITEM_MENUS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_orders($dbconn, $result){
			
		echo '<div align="center">
			<strong>ORDERS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "ORDERS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing ORDERS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_order_line($dbconn, $result){
			
		echo '<div align="center">
			<strong>ORDER_LINE</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "ORDER_LINE"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing ORDER_LINE<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_payments($dbconn, $result){
			
		echo '<div align="center">
			<strong>PAYMENTS</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "PAYMENTS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing PAYMENTS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_promo_codes($dbconn, $result){
			
		echo '<div align="center">
			<strong>PROMO_CODES</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "PROMO_CODES"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing PROMO_CODES<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}
	
	
	function show_customer_details($dbconn, $result){
			
		echo '<div align="center">
			<strong>CUSTOMER_DETAILS(view)</strong>
		</div>';
		
		$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
		pg_free_result($result);
		$sql = 'SELECT * FROM "CUSTOMER_DETAILS"';
		$result = pg_query($dbconn, $sql);
			
		if (!$result) {
			echo "<strong>Query error while showing CUSTOMER_DETAILS<strong></br>";
			exit;
		}else{
			show_table_data($result);
		}
		pg_free_result($result);

	}

?>



