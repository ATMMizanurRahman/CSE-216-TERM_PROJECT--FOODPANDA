<?php
	include 'execute_functions.php';
	
	$dbconn = @pg_connect("host = localhost port = 5432 dbname = FOODPANDA user = postgres password = postgres") 
			  or @die("<strong>Could not connect to DataBase.......<></br>");
			  
	echo "<strong>Successfully connected to ".pg_host($dbconn)."</strong><br>".str_repeat('&nbsp;', 5);
	
	
	$result = pg_query($dbconn, 'SELECT "FOODPANDA"."REFRESH_FOODPANDA_PATH"()');
	pg_free_result($result);


	if(isset($_POST['update_rider_status_input']) && !empty($_POST['update_rider_status_input'])){
		$rider_id = intval($_POST['update_rider_status_input']) or die("invalid value entered");
		update_rider_status($dbconn, $result, $rider_id);
	}
	else if((isset($_POST['give_ratings_input1']) && !empty($_POST['give_ratings_input1']))&&
		(isset($_POST['give_ratings_input2']) && !empty($_POST['give_ratings_input2']))&&
		(isset($_POST['give_ratings_input3']) && !empty($_POST['give_ratings_input3']))){
		
		$cus_id = intval($_POST['give_ratings_input1']) or die("invalid value entered");
		$res_id = intval($_POST['give_ratings_input2']) or die("invalid value entered");
		$koto = intval($_POST['give_ratings_input3']) or die("invalid value entered");
		give_ratings($dbconn, $result, $cus_id, $res_id, $koto);
	}
	else if(isset($_POST['discard_order_input']) && !empty($_POST['discard_order_input'])){
		$order_id = intval($_POST['discard_order_input']) or die("invalid value entered");
		discard_order($dbconn, $result, $order_id);
	}
	else if(isset($_POST['create_new_order_input']) && !empty($_POST['create_new_order_input'])){
		$cus_id = intval($_POST['create_new_order_input']) or die("invalid value entered");
		create_new_order($dbconn, $result, $cus_id);
	}
	else if(isset($_POST['update_order_price_input']) && !empty($_POST['update_order_price_input'])){
		$order_id = intval($_POST['update_order_price_input']) or die("invalid value entered");
		update_order_price($dbconn , $result, $order_id);
	}
?>



